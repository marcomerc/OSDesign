#include <stdio.h>
#pragma GCC push_options
#pragma GCC optimize("O0")
int fib(int n)
{
   if (n <= 1)
      return n;
   return fib(n-1) + fib(n-2);
}
#pragma GCC pop_options
 
int main(int argc, char *argv[])
{
  int n = 25;
  printf("start the test \n");
 printf("%d", fib(n));
  printf("done with the test \n");
 
return 0;
}

